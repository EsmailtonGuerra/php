package com.example.petcareapp.ui.admGerenciarTutor;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admGerenciarTutorFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admGerenciarTutorFragment extends Fragment {

    String emailUsuarioAtual, nomeClicadoTutor, telefoneClicadoTutor;
    Integer idUsuarioAtual, idClicadoTutor;
    boolean verificarLista = true;

    EditText admEmailTutor, admNomeTutor, admTelefoneTutor, etPesquisarTutor, admAlterarSenhaTutor, admAlterarConfSenhaTutor, admAlterarEmailTutor;
    ListView listaAllTutor;
    TextView admDeletarTutor;
    Button btAdmAlterarSenhaTutor, btAdmAlterarDadosTutor, btAdmAlterarEmailTutor;

    ArrayList<String> arrayListaAllTutor;
    ArrayList<String> arrayListaFiltradaTutor;

    ArrayAdapter<String> adapter;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admGerenciarTutorFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admGerenciarTutorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admGerenciarTutorFragment newInstance(String param1, String param2) {
        admGerenciarTutorFragment fragment = new admGerenciarTutorFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view = inflater.inflate(R.layout.fragment_adm_gerenciar_tutor, container, false);

       admEmailTutor = view.findViewById(R.id.admEmailTutor);
       admNomeTutor = view.findViewById(R.id.admNomeTutor);
       admTelefoneTutor = view.findViewById(R.id.admTelefoneTutor);
       admDeletarTutor = view.findViewById(R.id.admDeletarTutor);
       etPesquisarTutor = view.findViewById(R.id.etPesquisarTutor);
       listaAllTutor = view.findViewById(R.id.listaAllTutor);
       btAdmAlterarSenhaTutor = view.findViewById(R.id.btAdmAlterarSenhaTutor);
       btAdmAlterarDadosTutor = view.findViewById(R.id.btAdmAlterarDadosTutor);
       btAdmAlterarEmailTutor = view.findViewById(R.id.btAdmAlterarEmailTutor);
       admAlterarSenhaTutor = view.findViewById(R.id.admAlterarSenhaTutor);
       admAlterarConfSenhaTutor = view.findViewById(R.id.admAlterarConfSenhaTutor);
       admAlterarEmailTutor = view.findViewById(R.id.admAlterarEmailTutor);

        admEmailTutor.setFocusable(false);
        admEmailTutor.setFocusableInTouchMode(false);
        admEmailTutor.setCursorVisible(false);
        admEmailTutor.setLongClickable(false);

        etPesquisarTutor.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                funPesquisarTutor(s.toString());
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        listaAllTutor.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String clickedTutor = "";

                // Verifica se a lista filtrada foi preenchida
                if (arrayListaFiltradaTutor != null && !arrayListaFiltradaTutor.isEmpty()) {
                    // Recuperando o item clicado da lista filtrada
                    clickedTutor = arrayListaFiltradaTutor.get(position);
                } else if (arrayListaAllTutor != null && !arrayListaAllTutor.isEmpty()) {
                    // Caso contrário, recupera o item clicado da lista completa
                    clickedTutor = arrayListaAllTutor.get(position);
                }

                // Dividindo os valores de `itemClicked` (se necessário)
                String[] parts = clickedTutor.split("\n"); // Divindo os valores usando o separador ' | '

                // Acessando os valores
                if (parts.length >= 5) {
                    idClicadoTutor = Integer.valueOf(parts[1]);
                    admEmailTutor.setText(parts[2]);
                    admNomeTutor.setText(parts[3]);
                    nomeClicadoTutor = parts[3];
                    admTelefoneTutor.setText(parts[4]);
                    telefoneClicadoTutor = parts[4];
                    funAtivarCampos();
                    etPesquisarTutor.setText(null);
                }

                // Log para verificação
                Log.d("admGerenciarTutorFragment", "ID Tutor: " + idClicadoTutor);
            }
        });

        btAdmAlterarDadosTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAdmAlterarDadosTutor();
            }
        });

        admDeletarTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idClicadoTutor == null) {
                    Toast.makeText(getActivity(), "Nenhum tutor selecionado!", Toast.LENGTH_SHORT).show();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage("Você tem certeza que deseja excluir o tutor " + nomeClicadoTutor + "?")
                            .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Confirmar"
                                    funDeletarTutor();
                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Cancelar"
                                }
                            });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });

       return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funListaAllTutor();
        funDesativarCampos();
        funLimparCampos();
        etPesquisarTutor.setText(null);
    }

    public void funListaAllTutor() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM adm_info_tutor";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            arrayListaAllTutor= new ArrayList<>();

            while(rs.next()){
                arrayListaAllTutor.add("\n"+rs.getString("id_login") + "\n"+rs.getString("email") + "\n"+rs.getString("nome")
                        + "\n"+rs.getString("telefone") + "\n"+rs.getString("dt_nascimento") + "\n");
            }

            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arrayListaAllTutor);
            listaAllTutor.setAdapter(adapter);

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funPesquisarTutor(String termo) {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM adm_info_tutor WHERE " +
                    "unaccent(LOWER(email)) LIKE LOWER(?) OR unaccent(LOWER(nome)) LIKE LOWER(?) " +
                    "OR telefone LIKE ? OR dt_nascimento LIKE ?";
            PreparedStatement stmt = con.prepareStatement(sql);

            String filtro = "%" + termo.trim() + "%";
            for (int i = 1; i <= 4; i++) {
                stmt.setString(i, filtro);
            }

            // Agora usando a variável de classe
            arrayListaFiltradaTutor = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                arrayListaFiltradaTutor.add("\n" + rs.getString("id_login") +
                        "\n" + rs.getString("email") +
                        "\n" + rs.getString("nome") +
                        "\n" + rs.getString("telefone") +
                        "\n" + rs.getString("dt_nascimento") + "\n");
            }

            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arrayListaFiltradaTutor);
            listaAllTutor.setAdapter(adapter);

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            Log.e("ErroPesquisaTutor", "Erro ao pesquisar tutor", e);
        }
    }

    public void funAdmAlterarDadosTutor() {
        String nomeTutor = admNomeTutor.getText().toString().trim();
        String telefoneTutor = admTelefoneTutor.getText().toString().trim();

        if (!(admNomeTutor.isEnabled() && admTelefoneTutor.isEnabled())) {
            Toast.makeText(getActivity(), "Nenhum tutor selecionado!", Toast.LENGTH_SHORT).show();
        } else {
            if (nomeTutor.isEmpty() || telefoneTutor.isEmpty()) {
                Toast.makeText(getActivity(), "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            } else {
                if (nomeTutor.equals(nomeClicadoTutor) && telefoneTutor.equals(telefoneClicadoTutor)) {
                    Toast.makeText(getActivity(), "Nenhum dado alterado!", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        Connection con = ConexaoMysql.conectar();
                        String sql = "UPDATE tutor SET nome = ?, telefone = ? WHERE id_tutor = ?";
                        PreparedStatement stmt = con.prepareStatement(sql);
                        stmt.setString(1, nomeTutor);
                        stmt.setString(2, telefoneTutor);
                        stmt.setInt(3, idClicadoTutor);
                        stmt.executeUpdate();

                        stmt.close();
                        con.close();

                        funListaAllTutor();
                        funDesativarCampos();
                        funLimparCampos();
                        Toast.makeText(getActivity(), "Dados atualizados com sucesso!", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }
    }

    public void funDeletarTutor() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM login WHERE id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idClicadoTutor);
            stmt.execute();

            stmt.close();
            con.close();

            funListaAllTutor();
            funDesativarCampos();
            funLimparCampos();

            idClicadoTutor = null;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funDesativarCampos() {
        admNomeTutor.setFocusable(false);
        admNomeTutor.setFocusableInTouchMode(false);
        admNomeTutor.setCursorVisible(false);
        admNomeTutor.setLongClickable(false);

        admTelefoneTutor.setFocusable(false);
        admTelefoneTutor.setFocusableInTouchMode(false);
        admTelefoneTutor.setCursorVisible(false);
        admTelefoneTutor.setLongClickable(false);

        admAlterarSenhaTutor.setFocusable(false);
        admAlterarSenhaTutor.setFocusableInTouchMode(false);
        admAlterarSenhaTutor.setCursorVisible(false);
        admAlterarSenhaTutor.setLongClickable(false);

        admAlterarConfSenhaTutor.setFocusable(false);
        admAlterarConfSenhaTutor.setFocusableInTouchMode(false);
        admAlterarConfSenhaTutor.setCursorVisible(false);
        admAlterarConfSenhaTutor.setLongClickable(false);

        admAlterarEmailTutor.setFocusable(false);
        admAlterarEmailTutor.setFocusableInTouchMode(false);
        admAlterarEmailTutor.setCursorVisible(false);
        admAlterarEmailTutor.setLongClickable(false);
    }

    public void funAtivarCampos() {
        admNomeTutor.setFocusable(true);
        admNomeTutor.setFocusableInTouchMode(true);
        admNomeTutor.setCursorVisible(true);
        admNomeTutor.setLongClickable(true);

        admTelefoneTutor.setFocusable(true);
        admTelefoneTutor.setFocusableInTouchMode(true);
        admTelefoneTutor.setCursorVisible(true);
        admTelefoneTutor.setLongClickable(true);

        admAlterarSenhaTutor.setFocusable(true);
        admAlterarSenhaTutor.setFocusableInTouchMode(true);
        admAlterarSenhaTutor.setCursorVisible(true);
        admAlterarSenhaTutor.setLongClickable(true);

        admAlterarConfSenhaTutor.setFocusable(true);
        admAlterarConfSenhaTutor.setFocusableInTouchMode(true);
        admAlterarConfSenhaTutor.setCursorVisible(true);
        admAlterarConfSenhaTutor.setLongClickable(true);

        admAlterarEmailTutor.setFocusable(true);
        admAlterarEmailTutor.setFocusableInTouchMode(true);
        admAlterarEmailTutor.setCursorVisible(true);
        admAlterarEmailTutor.setLongClickable(true);
    }

    public void funLimparCampos() {
        admEmailTutor.setText(null);
        admNomeTutor.setText(null);
        admTelefoneTutor.setText(null);
        admAlterarSenhaTutor.setText(null);
        admAlterarConfSenhaTutor.setText(null);
        idClicadoTutor = null;
    }
}