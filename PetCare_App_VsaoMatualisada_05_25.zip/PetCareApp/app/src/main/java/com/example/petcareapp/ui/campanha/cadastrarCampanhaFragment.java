package com.example.petcareapp.ui.campanha;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_LONG;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;


import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link cadastrarCampanhaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class cadastrarCampanhaFragment extends Fragment {

    String emailUsuarioAtual, dataI,dataF, tipoData, ufSelecionadoCampanha, tipoUserAtual;
    private Integer idUsuarioAtual, id_camapnha_click;
    CalendarView calendario;
    EditText nomeCampanha, descCampanha, inicioCamapanha, fimCamapanha, fonteCampanha,
    logradouroEndCampanha, numeroEndCampanha, cepEndCampanha, bairroEndCampanha,
            cidadeEndCampanha, complementoEndCampanha;
    TextView endereco;
    Spinner estadoEndCampanha;
    Button btAlterarCamapanha, btMinhasCampanhas,btTodasCampanhas,
            btAtualizarCampanha,btDeletarCampanha;
    ListView listaMyCampanhas,listaAllCampanhas;
    ArrayList<String> dadosLista; //Onde guarda os dados
    ArrayAdapter<String> adapter1,adapter2,adapter3; //Adaptador para Startar os dados da lista.
    List<String> estadoList;
    boolean verificarBotoes=false, verificarMyCampanha=false,verificarAllCampanha=false;
    ImageButton btDataInicio,btDataFim,btAddNovaCampanha;
    //Formatação data
    String dataStringI = "inicio_campanha", dataStringF = "fim_campanha" ,dataFormatadaI, dataFormatadaF ; // Exemplo da data quando vem do banco de dados
    Date dataInicio,dataFim ; // Converte uma String para um objeto Date

    boolean campanhaIsNull = true; //  campanha caso exista

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public cadastrarCampanhaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment cadastrarCampanhaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static cadastrarCampanhaFragment newInstance(String param1, String param2) {
        cadastrarCampanhaFragment fragment = new cadastrarCampanhaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint({"CutPasteId", "MissingInflatedId", "WrongViewCast"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cadastrar_campanha, container, false);

        nomeCampanha = view.findViewById(R.id.nomeCampanha);
        descCampanha = view.findViewById(R.id.descCampanha);
        inicioCamapanha = view.findViewById(R.id.inicioCampanha);
        fimCamapanha = view.findViewById(R.id.fimCampanha);
        fonteCampanha = view.findViewById(R.id.fonteCampanha);
        logradouroEndCampanha = view.findViewById(R.id.logradouroEndCampanha);
        numeroEndCampanha = view.findViewById(R.id.numeroEndCampanha);
        cepEndCampanha = view.findViewById(R.id.cepEndCampanha);
        bairroEndCampanha = view.findViewById(R.id.bairroEndCampanha);
        cidadeEndCampanha = view.findViewById(R.id.cidadeEndCampanha);
        complementoEndCampanha = view.findViewById(R.id.complementoEndCampanha);
        estadoEndCampanha = view.findViewById(R.id.estadoEndCampanha);
        calendario=view.findViewById(R.id.calendario);
        endereco=view.findViewById(R.id.endereco);
        listaMyCampanhas = view.findViewById(R.id.listaMyCampanhas);
        listaAllCampanhas = view.findViewById(R.id.listaAllCampanhas);
        btMinhasCampanhas = view.findViewById(R.id.btMinhasCampanhas);
        btTodasCampanhas = view.findViewById(R.id.btTodasCampanhas);
        btAddNovaCampanha = view.findViewById(R.id.btAddNovaCampanha);
        btAlterarCamapanha = view.findViewById(R.id.btAlterarCampanha);
        btAtualizarCampanha=view.findViewById(R.id.btAtualizarCampanha);
        btDataInicio=view.findViewById(R.id.btDataInicio);
        btDataFim=view.findViewById(R.id.btDataFim);
        btDeletarCampanha=view.findViewById(R.id.btDeletarCampanha);

        calendario.setVisibility(GONE);



        // Criar a lista de estadoEndCampanha
            estadoList = Arrays.asList("Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Distrito Federal",
                    "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba",
                    "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia",
                    "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins");

            // Criar o ArrayAdapter e associar ao Spinner
            adapter1 = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, estadoList);
            adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            estadoEndCampanha.setAdapter(adapter1);

            atualizarMyListaCampanha();

        calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int ano, int meses, int dia) {
                if (tipoData.equals("inicio")) {
                    int mes = meses + 1;
                    inicioCamapanha.setText(String.format("%02d/%02d/%04d", dia, mes, ano));
                    dataI = String.format("%04d-%02d-%02d 00:00:00", ano, mes, dia); // CORRETO
                } else if (tipoData.equals("fim")) {
                    int mes = meses + 1;
                    fimCamapanha.setText(String.format("%02d/%02d/%04d", dia, mes, ano));
                    dataF = String.format("%04d-%02d-%02d 00:00:00", ano, mes, dia); // CORRETO
                }

                nomeCampanha.setVisibility(VISIBLE);
                descCampanha.setVisibility(VISIBLE);
                inicioCamapanha.setVisibility(VISIBLE);
                fimCamapanha.setVisibility(VISIBLE);
                fonteCampanha.setVisibility(VISIBLE);
                endereco.setVisibility(VISIBLE);
                logradouroEndCampanha.setVisibility(VISIBLE);
                cepEndCampanha.setVisibility(VISIBLE);
                numeroEndCampanha.setVisibility(VISIBLE);
                bairroEndCampanha.setVisibility(VISIBLE);
                cidadeEndCampanha.setVisibility(VISIBLE);
                estadoEndCampanha.setVisibility(VISIBLE);
                complementoEndCampanha.setVisibility(VISIBLE);
                listaMyCampanhas.setVisibility(VISIBLE);
                btAddNovaCampanha.setVisibility(VISIBLE);
                btMinhasCampanhas.setVisibility(VISIBLE);
                btTodasCampanhas.setVisibility(VISIBLE);
                listaAllCampanhas.setVisibility(VISIBLE);
                btDataInicio.setVisibility(VISIBLE);
                btDataFim.setVisibility(VISIBLE);
                calendario.setVisibility(GONE);
                btAtualizarCampanha.setVisibility(VISIBLE);
        }
        });

        btDataInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipoData= "inicio";
                calendario.setVisibility(VISIBLE);
                nomeCampanha.setVisibility(GONE);
                descCampanha.setVisibility(GONE);
                inicioCamapanha.setVisibility(GONE);
                fimCamapanha.setVisibility(GONE);
                fonteCampanha.setVisibility(GONE);
                endereco.setVisibility(GONE);
                logradouroEndCampanha.setVisibility(GONE);
                cepEndCampanha.setVisibility(GONE);
                numeroEndCampanha.setVisibility(GONE);
                bairroEndCampanha.setVisibility(GONE);
                cidadeEndCampanha.setVisibility(GONE);
                estadoEndCampanha.setVisibility(GONE);
                complementoEndCampanha.setVisibility(GONE);
                btAtualizarCampanha.setVisibility(GONE);
                btAlterarCamapanha.setVisibility(GONE);
                btAddNovaCampanha.setVisibility(GONE);
                btMinhasCampanhas.setVisibility(GONE);
                btTodasCampanhas.setVisibility(GONE);
                listaAllCampanhas.setVisibility(GONE);
                listaMyCampanhas.setVisibility(GONE);
                btDataInicio.setVisibility(GONE);
                btDataFim.setVisibility(GONE);
                btDeletarCampanha.setVisibility(GONE);

            }
        });

        btDataFim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipoData= "fim";
                calendario.setVisibility(VISIBLE);
                nomeCampanha.setVisibility(GONE);
                descCampanha.setVisibility(GONE);
                inicioCamapanha.setVisibility(GONE);
                fimCamapanha.setVisibility(GONE);
                fonteCampanha.setVisibility(GONE);
                endereco.setVisibility(GONE);
                logradouroEndCampanha.setVisibility(GONE);
                cepEndCampanha.setVisibility(GONE);
                numeroEndCampanha.setVisibility(GONE);
                bairroEndCampanha.setVisibility(GONE);
                cidadeEndCampanha.setVisibility(GONE);
                estadoEndCampanha.setVisibility(GONE);
                complementoEndCampanha.setVisibility(GONE);
                btAtualizarCampanha.setVisibility(GONE);
                btAlterarCamapanha.setVisibility(GONE);
                btAddNovaCampanha.setVisibility(GONE);
                btMinhasCampanhas.setVisibility(GONE);
                btTodasCampanhas.setVisibility(GONE);
                listaAllCampanhas.setVisibility(GONE);
                listaMyCampanhas.setVisibility(GONE);
                btDataInicio.setVisibility(GONE);
                btDataFim.setVisibility(GONE);
                btDeletarCampanha.setVisibility(GONE);
            }
        });

        btAtualizarCampanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btAtualizarCampanha.setVisibility(VISIBLE);
                funAtualizarCamapnhaCadastrada();
                funLimparCamposCadastroCamp();
                funDesativarCamposCampanhas();
                funEscondeCamposCampanha();

            }
        });

        btMinhasCampanhas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                atualizarMyListaCampanha();
                funEscondeCamposCampanha();

                if (verificarMyCampanhaNull()){
                    listaAllCampanhas.setVisibility(GONE);
                    listaMyCampanhas.setVisibility(VISIBLE);


                    Toast.makeText(getContext(), "Lista com SUAS campanhas!!", Toast.LENGTH_SHORT).show();
                }
                else {
                    listaAllCampanhas.setVisibility(GONE);
                    listaMyCampanhas.setVisibility(GONE);
                    Toast.makeText(getContext(), "Você não possui campanhas cadastradas!!"+verificarMyCampanhaNull(), Toast.LENGTH_SHORT).show();
                }

                btMinhasCampanhas.setVisibility(GONE);
                btTodasCampanhas.setVisibility(VISIBLE);


            }
        });

        btTodasCampanhas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                atualizarAllListaCampanha();
                funEscondeCamposCampanha();
               // Log.d(cadastrarCampanhaFragment,"teste de condicao my campanha"+verificarMyCampanhaNull());

                if (verificarAllCampanhaNull()){

                    listaMyCampanhas.setVisibility(GONE);
                    listaAllCampanhas.setVisibility(VISIBLE);


                    Toast.makeText(getContext(), "Lista com TODAS camapnhas!", Toast.LENGTH_SHORT).show();
                }
                else {
                    listaMyCampanhas.setVisibility(GONE);
                    listaAllCampanhas.setVisibility(GONE);

                    Toast.makeText(getContext(), "Não possui campanhas cadastradas no sistema!!"+ verificarAllCampanhaNull(), Toast.LENGTH_SHORT).show();
                }

                btTodasCampanhas.setVisibility(GONE);
                btMinhasCampanhas.setVisibility(VISIBLE);


            }
        });

        listaMyCampanhas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                verificarBotoes=false;
                calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                    @Override
                    public void onSelectedDayChange(@NonNull CalendarView view, int ano, int meses, int dia) {
                        if (tipoData == "inicio"){
                            int mes = meses+1;
                            inicioCamapanha.setText(String.format("%02d/%02d/%04d",dia,mes,ano));
                            dataI= ano+"-"+mes+"-"+dia;
                            Toast.makeText(getContext(),dataI, LENGTH_LONG).show();

                        }
                        else if (tipoData =="fim"){
                            int mes = meses+1;
                            fimCamapanha.setText(String.format("%02d/%02d/%04d",dia,mes,ano));
                            dataF= ano+"-"+mes+"-"+dia;
                            Toast.makeText(getContext(),dataF, LENGTH_LONG).show();
                        }
                    }
                });
                funMostraCamposCampanha();
                funDesativarCamposCampanhas();

                String selectedItem = adapter2.getItem(position);
                String texto = selectedItem;
                String[] partes = texto.split("\n");

                id_camapnha_click = Integer.valueOf(partes[0]);

                //Ação do botão para quando clicar em algo da lista,ele pegar os dados
                Toast.makeText(getContext(), "Item selecionado " + partes[0], Toast.LENGTH_SHORT).show();

                funSelecionarCampanha();
                btDeletarCampanha.setVisibility(VISIBLE); //botao adicoonado para quem cadastrou a devida campanha conseguir excluir a campanha
            }
        });

        listaAllCampanhas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                verificarBotoes=false;
                calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                    @Override
                    public void onSelectedDayChange(@NonNull CalendarView view, int ano, int meses, int dia) {
                        if (tipoData == "inicio"){
                            int mes = meses+1;
                            inicioCamapanha.setText(String.format("%02d/%02d/%04d",dia,mes,ano));
                            dataI= ano+"-"+mes+"-"+dia;
                            Toast.makeText(getContext(),dataI, LENGTH_LONG).show();

                        }
                        else if (tipoData =="fim"){
                            int mes = meses+1;
                            fimCamapanha.setText(String.format("%02d/%02d/%04d",dia,mes,ano));

                            Toast.makeText(getContext(),dataF, LENGTH_LONG).show();
                        }
                    }
                });


                funMostraCamposCampanha();
                funDesativarCamposCampanhas();
                String selectedItem = adapter3.getItem(position);
                String texto = selectedItem;
                String[] partes = texto.split("\n");

                id_camapnha_click = Integer.valueOf(partes[0]);

                //Ação do botão para quando clicar em algo da lista,ele pegar os dados
                Toast.makeText(getContext(), "Item selecionado " + partes[0], Toast.LENGTH_SHORT).show();

                funSelecionarCampanha();
                btDeletarCampanha.setVisibility(GONE);
                btAlterarCamapanha.setVisibility(GONE);
            }
        });

        btAlterarCamapanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCamposCampanhas();

                btAlterarCamapanha.setVisibility(GONE);
                btAtualizarCampanha.setVisibility(VISIBLE);
                btDeletarCampanha.setVisibility(VISIBLE);
            }
        });

        btAddNovaCampanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavController navController = Navigation.findNavController(view);//Para fazer a navegação
                navController.navigate(R.id.nav_novaCampanha);//Navegar para outra tela

            }
        });
        btDeletarCampanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Certeza que deseja excluir esta campanha?")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirma", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarCampanha();
                            }
                        }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });

        return  view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, tipo_user FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                tipoUserAtual = rs.getString("tipo_user");
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        inicioCamapanha.setEnabled(false);
        fimCamapanha.setEnabled(false);

        funDesativarCamposCampanhas();
        atualizarAllListaCampanha();
        atualizarMyListaCampanha();
        funEscondeCamposCampanha();

        if (verificarAllCampanhaNull()){
            listaAllCampanhas.setVisibility(VISIBLE);
            listaMyCampanhas.setVisibility(GONE);
        }
        else {
            listaAllCampanhas.setVisibility(GONE);
            listaMyCampanhas.setVisibility(GONE);
        }

    }

    public void funSelecionarCampanha(){
        try {
            Connection con = ConexaoMysql.conectar();
                    /*id_alerta_campanha, nome_campanha, desc_campanha, inicio_campanha, fim_campanha, fonte_web,
                     cep, logradouro, numero, complemento, bairro, cidade, estado*/
            String sql = "SELECT*FROM info_campanha WHERE id_alerta_campanha=?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,id_camapnha_click);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                ufSelecionadoCampanha = rs.getString("estado");
                int posicaoEstadoCamp = estadoList.indexOf(ufSelecionadoCampanha);
                estadoEndCampanha.setSelection(posicaoEstadoCamp);

                nomeCampanha.setText(rs.getString("nome_campanha"));
                descCampanha.setText(rs.getString("desc_campanha"));
                dataInicio = (rs.getDate("inicio_campanha"));
                dataFim= (rs.getDate("fim_campanha"));
                fonteCampanha.setText(rs.getString("fonte_web"));
                cepEndCampanha.setText(rs.getString("cep"));
                logradouroEndCampanha.setText(rs.getString("logradouro"));
                numeroEndCampanha.setText(rs.getString("numero"));
                bairroEndCampanha.setText(rs.getString("bairro"));
                cidadeEndCampanha.setText(rs.getString("cidade"));
                complementoEndCampanha.setText(rs.getString("complemento"));

                //formatacao da data ao buscar do banco de dados
                SimpleDateFormat data_formatada = new SimpleDateFormat( "dd/MM/yyyy" , Locale. getDefault ());
                String dataII = data_formatada.format(dataInicio);
                String dataFF = data_formatada.format(dataFim);
                inicioCamapanha.setText(dataII);
                fimCamapanha.setText(dataFF);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void funAtualizarCamapnhaCadastrada(){
        String nome = nomeCampanha.getText().toString().trim();
        String descricao = descCampanha.getText().toString().trim();
        String fonte = fonteCampanha.getText().toString().trim();
        String logradouro = logradouroEndCampanha.getText().toString().trim();
        String numero = numeroEndCampanha.getText().toString().trim();
        String complemento = complementoEndCampanha.getText().toString().trim();
        String bairro = bairroEndCampanha.getText().toString().trim();
        String cidade = cidadeEndCampanha.getText().toString().trim();
        String cep = cepEndCampanha.getText().toString().trim();
        String inicio = inicioCamapanha.getText().toString().trim();
        String fim = fimCamapanha.getText().toString().trim();

        if (!(nome.isEmpty()||descricao.isEmpty()||fonte.isEmpty()||logradouro.isEmpty()||
                numero.isEmpty()||complemento.isEmpty()||bairro.isEmpty()||cidade.isEmpty()||
                cep.isEmpty()||inicio.isEmpty()||fim.isEmpty())){
            try {
                if (dataI==null&&dataF==null){
                    Connection con = ConexaoMysql.conectar();
                    /*id_alerta_campanha, nome_campanha, desc_campanha, inicio_campanha, fim_campanha, fonte_web, fk_id_clinica*/
                    String sql ="UPDATE alerta_campanhas SET nome_campanha=?,desc_campanha=?," +
                            "fonte_web=? WHERE id_alerta_campanha=?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1,nomeCampanha.getText().toString());
                    stmt.setString(2,descCampanha.getText().toString());
                    stmt.setString(3,fonteCampanha.getText().toString());
                    stmt.setInt(4,id_camapnha_click);
                    stmt.executeUpdate();

                    /*id_endereco_campanha, logradouro, numero, complemento, bairro, cidade, cep, estado, fk_id_alerta_campanhas*/
                    sql="UPDATE endereco_campanha SET logradouro=?,numero=?,complemento=?,bairro=?,cidade=?,cep=?,estado=? " +
                            "WHERE fk_id_alerta_campanhas=?";
                    /*"fk_id_alerta_campanhas=? WHERE id_endereco_campanha=?;*/
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1,logradouroEndCampanha.getText().toString());
                    stmt.setString(2,numeroEndCampanha.getText().toString());
                    stmt.setString(3,complementoEndCampanha.getText().toString());
                    stmt.setString(4,bairroEndCampanha.getText().toString());
                    stmt.setString(5,cidadeEndCampanha.getText().toString());
                    stmt.setString(6,cepEndCampanha.getText().toString());
                    stmt.setString(7,estadoEndCampanha.getSelectedItem().toString());
                    stmt.setInt(8,id_camapnha_click);
                    // stmt.setString(9,id_ec);

                    stmt.executeUpdate();

                    stmt.close();
                    con.close();

                    Toast.makeText(getActivity(), "Campanha ATUALIZADA/ALTERADA!", Toast.LENGTH_SHORT).show();

                }
                else {
                    Connection con = ConexaoMysql.conectar();
                    /*id_alerta_campanha, nome_campanha, desc_campanha, inicio_campanha, fim_campanha, fonte_web, fk_id_clinica*/
                    String sql ="UPDATE alerta_campanhas SET nome_campanha=?,desc_campanha=?,inicio_campanha=?,fim_campanha=?," +
                            "fonte_web=? WHERE id_alerta_campanha=?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1,nomeCampanha.getText().toString());
                    stmt.setString(2,descCampanha.getText().toString());

                    Timestamp timestampI = Timestamp.valueOf(dataI);
                    stmt.setTimestamp(3,timestampI);

                    Timestamp timestampF = Timestamp.valueOf(dataF);
                    stmt.setTimestamp(4,timestampF);

                    stmt.setString(5,fonteCampanha.getText().toString());
                    stmt.setInt(6,id_camapnha_click);
                    stmt.executeUpdate();

                    /*id_endereco_campanha, logradouro, numero, complemento, bairro, cidade, cep, estado, fk_id_alerta_campanhas*/
                    sql="UPDATE endereco_campanha SET logradouro=?,numero=?,complemento=?,bairro=?,cidade=?,cep=?,estado=? " +
                            "WHERE fk_id_alerta_campanhas=?";
                    /*"fk_id_alerta_campanhas=? WHERE id_endereco_campanha=?;*/
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1,logradouroEndCampanha.getText().toString());
                    stmt.setString(2,numeroEndCampanha.getText().toString());
                    stmt.setString(3,complementoEndCampanha.getText().toString());
                    stmt.setString(4,bairroEndCampanha.getText().toString());
                    stmt.setString(5,cidadeEndCampanha.getText().toString());
                    stmt.setString(6,cepEndCampanha.getText().toString());
                    stmt.setString(7,estadoEndCampanha.getSelectedItem().toString());
                    stmt.setInt(8,id_camapnha_click);
                    // stmt.setString(9,id_ec);

                    stmt.executeUpdate();

                    stmt.close();
                    con.close();

                    Toast.makeText(getActivity(), "Campanha ATUALIZADA/ALTERADA!", Toast.LENGTH_SHORT).show();
                }


            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        else {
            Toast.makeText(getActivity(), "Preencha todos os campos para ATUALIZAR", Toast.LENGTH_SHORT).show();
        }
    }

    public void atualizarMyListaCampanha() {
        try {
            // Verificação para evitar NullPointerException
            if (idUsuarioAtual == null) {
                Log.e("atualizarMyListaCampanha", "idUsuarioAtual está nulo!");
                return;
            }

            Connection con = ConexaoMysql.conectar();
            if (con == null) {
                Log.e("atualizarMyListaCampanha", "Falha na conexão com o banco de dados.");
                return;
            }

            String sql = "SELECT * FROM info_campanha WHERE id_clinica = ? ORDER BY id_alerta_campanha;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);

            ResultSet rs = stmt.executeQuery();
            dadosLista = new ArrayList<>();

            while (rs.next()) {
                dadosLista.add(
                        rs.getString("id_alerta_campanha") + "\n" +
                                "Campanha: " + rs.getString("nome_campanha") + "\n" +
                                "Início: " + rs.getString("inicio_campanha") + "\n" +
                                "Fim: " + rs.getString("fim_campanha") + "\n" +
                                "Fonte: " + rs.getString("fonte_web") + "\n" +
                                "Estado: " + rs.getString("estado") + "\n" +
                                "Cidade: " + rs.getString("cidade") + "\n"
                );
            }

            if (campanhaIsNull) {
                adapter2 = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, dadosLista);
                listaMyCampanhas.setAdapter(adapter2);
            } else {
                btTodasCampanhas.setVisibility(View.VISIBLE);
                listaMyCampanhas.setVisibility(View.GONE);
            }

            // Fechando recursos
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException e) {
            Log.e("atualizarMyListaCampanha", "Erro ao carregar campanhas: " + e.getMessage(), e);
        }
    }


    public void atualizarAllListaCampanha(){
        //Não resolveu puxar pela formatacao do caledario.
      /* calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int ano, int meses, int dia) {
                if (tipoData == "inicio"){
                    int mes = meses+1;
                    inicioCamapanha.setText(String.format("%02d/%02d/%04d",dia,mes,ano));
                    dataI= ano+"-"+mes+"-"+dia;
                    Toast.makeText(getContext(),dataI, LENGTH_LONG).show();

                }
                else if (tipoData =="fim"){
                    int mes = meses+1;
                    fimCamapanha.setText(String.format("%02d/%02d/%04d",dia,mes,ano));
                    dataF= ano+"-"+mes+"-"+dia;
                    Toast.makeText(getContext(),dataF, LENGTH_LONG).show();
                }
            }
        });*/
        try {
            Connection con = ConexaoMysql.conectar();
            /*id_alerta_campanha, nome_campanha, desc_campanha, inicio_campanha, fim_campanha, fonte_web,
             logradouro, cep, numero, bairro, cidade, estado, complemento*/
            String sql = "SELECT*FROM info_campanha ORDER BY id_alerta_campanha;";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            dadosLista = new ArrayList<>();
            while (rs.next()){
                dadosLista.add(rs.getString("id_alerta_campanha")+
                        "\n"+"Campanha: "+rs.getString("nome_campanha") +
                        "\n"+"Início: "+rs.getString("inicio_campanha")+
                        "\n"+"Fim: "+rs.getString("fim_campanha")+
                        "\n"+"Fonte: "+rs.getString("fonte_web")+
                        "\n"+"Estado: "+rs.getString("estado")+
                        "\n"+"Cidade: "+rs.getString("cidade")+
                        "\n");
            }
            if(campanhaIsNull) {
                adapter3 =new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1,dadosLista);
                listaAllCampanhas.setAdapter(adapter3);
            } else {
                btMinhasCampanhas.setVisibility(VISIBLE);
                listaAllCampanhas.setVisibility(GONE);
            }

            stmt.close();
            rs.close();
            con.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void funDeletarCampanha(){
        Connection con = ConexaoMysql.conectar();
        String sql = "DELETE FROM alerta_campanhas WHERE id_alerta_campanha = ? AND fk_id_clinica=?";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,id_camapnha_click);
            stmt.setInt(2,idUsuarioAtual);
            stmt.execute();

            stmt.close();
            con.close();

            atualizarMyListaCampanha();
            atualizarAllListaCampanha();
            funEscondeCamposCampanha();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public boolean verificarMyCampanhaNull(){
        verificarMyCampanha=false;
        Connection con = ConexaoMysql.conectar();
        String sql = "SELECT*FROM info_campanha WHERE id_clinica=? LIMIT 1";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                verificarMyCampanha=true;
            }
            stmt.execute();

            stmt.close();
            con.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return verificarMyCampanha;
    }
    public boolean verificarAllCampanhaNull(){
        verificarAllCampanha=false;
        Connection con = ConexaoMysql.conectar();
        String sql = "SELECT*FROM info_campanha LIMIT 1";
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            //stmt.setString(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                verificarAllCampanha=true;
            }
            stmt.execute();

            stmt.close();
            con.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return  verificarAllCampanha;
    }

    public void funLimparCamposCadastroCamp(){
        nomeCampanha.setText(null);
        descCampanha.setText(null);
        inicioCamapanha.setText(null);
        fimCamapanha.setText(null);
        fonteCampanha.setText(null);
        logradouroEndCampanha.setText(null);
        cepEndCampanha.setText(null);
        numeroEndCampanha.setText(null);
        bairroEndCampanha.setText(null);
        cidadeEndCampanha.setText(null);
        estadoEndCampanha.setSelection(0);
        complementoEndCampanha.setText(null);
    }

    public void funDesativarCamposCampanhas(){
        nomeCampanha.setEnabled(false);
        descCampanha.setEnabled(false);
        inicioCamapanha.setEnabled(false);
        fimCamapanha.setEnabled(false);
        fonteCampanha.setEnabled(false);
        logradouroEndCampanha.setEnabled(false);
        numeroEndCampanha.setEnabled(false);
        cepEndCampanha.setEnabled(false);
        bairroEndCampanha.setEnabled(false);
        cidadeEndCampanha.setEnabled(false);
        estadoEndCampanha.setEnabled(false);
        complementoEndCampanha.setEnabled(false);
        btDataInicio.setEnabled(false);
        btDataFim.setEnabled(false);
        btAtualizarCampanha.setVisibility(GONE);
        btAlterarCamapanha.setVisibility(VISIBLE);
        //btCancelarCadastroCamp.setVisibility(GONE);
    }
    public void funAtivarCamposCampanhas(){
        nomeCampanha.setEnabled(true);
        descCampanha.setEnabled(true);
        inicioCamapanha.setEnabled(false);
        fimCamapanha.setEnabled(false);
        fonteCampanha.setEnabled(true);
        logradouroEndCampanha.setEnabled(true);
        numeroEndCampanha.setEnabled(true);
        cepEndCampanha.setEnabled(true);
        bairroEndCampanha.setEnabled(true);
        cidadeEndCampanha.setEnabled(true);
        estadoEndCampanha.setEnabled(true);
        complementoEndCampanha.setEnabled(true);
        btAlterarCamapanha.setVisibility(GONE);
        btDataInicio.setEnabled(true);
        btDataFim.setEnabled(true);
    }

    public void funEscondeCamposCampanha(){

        nomeCampanha.setVisibility(GONE);
        descCampanha.setVisibility(GONE);
        inicioCamapanha.setVisibility(GONE);
        fimCamapanha.setVisibility(GONE);
        fonteCampanha.setVisibility(GONE);
        logradouroEndCampanha.setVisibility(GONE);
        numeroEndCampanha.setVisibility(GONE);
        cepEndCampanha.setVisibility(GONE);
        bairroEndCampanha.setVisibility(GONE);
        cidadeEndCampanha.setVisibility(GONE);
        estadoEndCampanha.setVisibility(GONE);
        complementoEndCampanha.setVisibility(GONE);
        endereco.setVisibility(GONE);
        btAlterarCamapanha.setVisibility(GONE);
        btAtualizarCampanha.setVisibility(GONE);
        btDataInicio.setVisibility(GONE);
        btDataFim.setVisibility(GONE);
        btDeletarCampanha.setVisibility(GONE);
    }

    public void funMostraCamposCampanha(){

        nomeCampanha.setVisibility(VISIBLE);
        descCampanha.setVisibility(VISIBLE);
        inicioCamapanha.setVisibility(VISIBLE);
        fimCamapanha.setVisibility(VISIBLE);
        fonteCampanha.setVisibility(VISIBLE);
        logradouroEndCampanha.setVisibility(VISIBLE);
        numeroEndCampanha.setVisibility(VISIBLE);
        cepEndCampanha.setVisibility(VISIBLE);
        bairroEndCampanha.setVisibility(VISIBLE);
        cidadeEndCampanha.setVisibility(VISIBLE);
        estadoEndCampanha.setVisibility(VISIBLE);
        complementoEndCampanha.setVisibility(VISIBLE);
        endereco.setVisibility(VISIBLE);
        btAlterarCamapanha.setVisibility(VISIBLE);
        btDataInicio.setVisibility(VISIBLE);
        btDataFim.setVisibility(VISIBLE);
        btDeletarCampanha.setVisibility(VISIBLE);
    }

}