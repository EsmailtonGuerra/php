package com.example.petcareapp;

import android.os.StrictMode;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoMysql {
    private static final String URL = "jdbc:postgresql://ep-black-tree-ac78hjdk-pooler.sa-east-1.aws.neon.tech:5432/projeto_pet_care?sslmode=require";
    private static final String USUARIO = "neondb_owner";
    private static final String SENHA = "npg_CdzGSDEgv5T7";

    public static Connection conectar() {
        try {
            // Carregar driver PostgreSQL
            Class.forName("org.postgresql.Driver");

            // Permitir conexao no thread principal (não recomendado para produção)
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Driver PostgreSQL não encontrado.", e);
        } catch (SQLException e) {
            System.out.println("Erro ao conectar: " + e.getMessage());
            return null;
        }
    }

    public static void fecharConexao(Connection conexao) {
        try {
            if (conexao != null) {
                conexao.close();
            }
        } catch (SQLException e) {
            System.out.println("Erro ao fechar conexão: " + e.getMessage());
        }
    }
}
