package com.example.petcareapp.ui.cartaoVacina;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;

import java.util.ArrayList;

public abstract class MainAdapterVacina extends RecyclerView.Adapter<MainAdapterVacina.ViewHolder> {
    ArrayList<MainModelVacina> mainModels;
    Context context;
    private OnItemClickListener listener;
    private MainModelVacina model;

    public abstract void onItemClick(MainAdapterVacina model);

    // Interface para lidar com o clique do item
    public interface OnItemClickListener {
        void onItemClick(MainModelVacina model);
    }

    // Construtor que aceita o listener
    public MainAdapterVacina(Context context, ArrayList<MainModelVacina> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    public MainAdapterVacina(FragmentActivity activity, ArrayList<MainModelVacina> mainModels) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Criando view
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_item_vacina,parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Set foto do pet para ImageView
        holder.listaFotoPetVac.setImageBitmap(mainModels.get(position).getListaFotoPetVac());

        // Set nome do pet para TextView
        holder.listaNomePetVac.setText(mainModels.get(position).getListaNomePetVac());

        holder.listaIdPetVac.setText(mainModels.get(position).getListaIdPetVac());


        // Configura o listener de clique
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(mainModels.get(position));  // Passa o item clicado para o listener
            } else {
                Log.e("MainAdapter", "Listener is null!");  // Log para ajudar a diagnosticar
            }
        });

        // Limitar o texto do nome do pet para 15 caracteres
        String nomePet = mainModels.get(position).getListaNomePetVac();
        int maxLength = 10;  // Limite de caracteres
        if (nomePet.length() > maxLength) {
            nomePet = nomePet.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaNomePetVac.setText(nomePet);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;  // Retorna 0 se a lista for null
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // Inicia variável
        ImageView listaFotoPetVac;
        TextView listaNomePetVac;
        TextView listaIdPetVac;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            listaFotoPetVac = itemView.findViewById(R.id.listaPetFotoVac);
            listaNomePetVac = itemView.findViewById(R.id.listaNomePetVac);
            listaIdPetVac = itemView.findViewById(R.id.listaIdPetVac);


            // Limitar o texto para 1 linha e aplicar elipse
            listaNomePetVac.setMaxLines(1);
            listaNomePetVac.setEllipsize(TextUtils.TruncateAt.END);
        }
    }
}
