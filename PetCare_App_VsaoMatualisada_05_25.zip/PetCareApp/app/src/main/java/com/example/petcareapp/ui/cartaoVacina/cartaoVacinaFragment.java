package com.example.petcareapp.ui.cartaoVacina;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.view.View.generateViewId;
import static android.widget.Toast.LENGTH_LONG;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.MainModel;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link cartaoVacinaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class cartaoVacinaFragment extends Fragment {

    String emailUsuarioAtual, especieSelecionada, nomeVacinaClicada;
    String ultimaEspecieSelecionada = "";
    Integer idUsuarioAtual, idPetClicadoVac, idCartaoClicado;

    RecyclerView listaVacina, listaCartaoVacina;

    EditText nome_vacina, dt_vacinacao, lote_vacina, medico_vet, clinica_vet;

    Button btSalvarVacina, btAtualizarVacina, btAlterarVacina, btDeletarVacina, btVacAplicadas, btVacProximas;

    ImageView btAddNovaVacina;

    Spinner filtrarEspecieVac;

    TextView tvFiltrarEspecieVac, tvPetNull, tvVacinas, tvNovaVacina,
            tvVacina, tvNomeVacina, tvLoteVacina, tvDataVacina, tvMedicoVet, tvClinicaVet;

    CalendarView calendarVac;

    boolean petIsNull = true;
    boolean vacinaIsNull = true;
    boolean verificarBt;
    boolean primeiraSelecaoSpinner = true; // Flag para ignorar primeira seleção do spinner quando ele e carregado

    ArrayList<String> listaNomePetVac = new ArrayList<>();
    ArrayList<Bitmap> listaFotoPetVac = new ArrayList<>();
    ArrayList<String> listaIdPetVac = new ArrayList<>();


    // Recylerview Cartao Vacina
    ArrayList<String> listaIdCartao = new ArrayList<>();
    ArrayList<String> listaNomeCartao = new ArrayList<>();
    ArrayList<String> listadtVacina = new ArrayList<>();

    ArrayList<MainModelVacina> mainModels = new ArrayList<>();
    ArrayList<MainModelCartaoVacina> mainModelsCartao = new ArrayList<>();

    MainAdapterVacina mainAdapter;
    MainAdapterCartaoVacina mainAdapterCartao;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public cartaoVacinaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment cartaoVacinaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static cartaoVacinaFragment newInstance(String param1, String param2) {
        cartaoVacinaFragment fragment = new cartaoVacinaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cartao_vacina, container, false);

        tvFiltrarEspecieVac = view.findViewById(R.id.tvFiltrarEspecieVac);
        filtrarEspecieVac = view.findViewById(R.id.filtrarEspecieVac);
        nome_vacina = view.findViewById(R.id.nome_vacina);
        dt_vacinacao = view.findViewById(R.id.dt_vacinacao);
        lote_vacina = view.findViewById(R.id.lote_vacina);
        medico_vet = view.findViewById(R.id.medico_vet);
        clinica_vet = view.findViewById(R.id.clinica_vet);
        btSalvarVacina = view.findViewById(R.id.btSalvarVacina);
        btAddNovaVacina = view.findViewById(R.id.btAddNovaVacina);
        listaVacina = view.findViewById(R.id.listaVacina);
        listaCartaoVacina = view.findViewById(R.id.listaCartaoVacina);
        tvVacinas = view.findViewById(R.id.tvVacinas);
        tvPetNull = view.findViewById(R.id.tvPetNull);
        tvNovaVacina = view.findViewById(R.id.tvNovaVacina);
        btAtualizarVacina = view.findViewById(R.id.btAtualizarVacina);
        btAlterarVacina = view.findViewById(R.id.btAlterarVacina);
        tvVacina = view.findViewById(R.id.tvVacina);
        btDeletarVacina = view.findViewById(R.id.btDeletarVacina);
        tvNomeVacina = view.findViewById(R.id.tvNomeVacina);
        tvLoteVacina = view.findViewById(R.id.tvLoteVacina);
        tvDataVacina = view.findViewById(R.id.tvDataVacina);
        tvMedicoVet = view.findViewById(R.id.tvMedicoVet);
        tvClinicaVet = view.findViewById(R.id.tvClinicaVet);
        calendarVac = view.findViewById(R.id.calendarVac);
        btVacAplicadas = view.findViewById(R.id.btVacAplicada);
        btVacProximas = view.findViewById(R.id.btVacProximas);

        calendarVac.setVisibility(GONE);

        dt_vacinacao.setFocusable(false);
        dt_vacinacao.setFocusableInTouchMode(false);
        dt_vacinacao.setCursorVisible(false);
        dt_vacinacao.setLongClickable(false);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.HORIZONTAL,false
        );
        listaVacina.setLayoutManager(layoutManager);
        listaVacina.setItemAnimator(new DefaultItemAnimator());

        // Design Horizontal Layout Cartao Vacina
        LinearLayoutManager layoutManagerCartao = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaCartaoVacina.setLayoutManager(layoutManagerCartao);
        listaCartaoVacina.setItemAnimator(new DefaultItemAnimator());

        mainAdapter = new MainAdapterVacina(getActivity(), mainModels, new MainAdapterVacina.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelVacina model) {
                // Obtenha o nome do pet do modelo
                idPetClicadoVac = Integer.valueOf(model.getListaIdPetVac());

                // Sempre chamar funListaCartao para atualizar vacinaIsNull e a lista de cartão
                funListaCartao();

                if (vacinaIsNull) {
                    funVacinaNull();
                    funLimparCamposVacina();
                    funAtivarCamposVacina();
                } else {
                    funMostrarVacinas();
                }

            }
        }) {
            @Override
            public void onItemClick(MainAdapterVacina model) {

            }
        };

        mainAdapterCartao = new MainAdapterCartaoVacina(getActivity(), mainModelsCartao, new MainAdapterCartaoVacina.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelCartaoVacina model) {
                idCartaoClicado = Integer.valueOf(model.getListaIdCartao());
                nomeVacinaClicada = model.getListaNomeVacina();

                try {
                    Connection con = ConexaoMysql.conectar();
                    String sql = "SELECT * FROM view_cartao_vacinacao WHERE id_cartao_vacinacao = ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idCartaoClicado);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        nome_vacina.setText(rs.getString("nome_vacina"));

                        Date dataNascimento = rs.getDate("dt_vacinacao");
                        if (dataNascimento != null) {
                            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                            String dataFormatada = formato.format(dataNascimento);
                            dt_vacinacao.setText(dataFormatada);
                        }

                        lote_vacina.setText(rs.getString("lote_vacina"));
                        medico_vet.setText(rs.getString("medico_vet"));
                        clinica_vet.setText(rs.getString("clinica_vet"));
                    }

                    rs.close();
                    stmt.close();
                    con.close();

                    funMostrarLayoutVacina();
                    funDesativarCamposVacina();

                } catch (Exception e) {
                    e.printStackTrace();
                    // Lança uma exceção personalizada ou trata o erro conforme necessário
                    throw new RuntimeException("Erro ao buscar detalhes da vacina", e);
                }
            }
        });

        listaVacina.setAdapter(mainAdapter);
        listaCartaoVacina.setAdapter(mainAdapterCartao);

        calendarVac.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int ano, int meses, int dia) {
                int mes = meses+1;
                dt_vacinacao.setText(String.format("%02d/%02d/%04d", dia, mes, ano));
                calendarVac.setVisibility(GONE);

                if (verificarBt) {
                    funMostrarListaVacina();
                    btDeletarVacina.setVisibility(GONE);
                    btAtualizarVacina.setVisibility(GONE);
                    tvVacina.setVisibility(GONE);
                    tvNovaVacina.setVisibility(VISIBLE);
                    btSalvarVacina.setVisibility(VISIBLE);
                } else {
                    funMostrarListaVacina();
                    btSalvarVacina.setVisibility(GONE);
                    tvNovaVacina.setVisibility(GONE);
                    tvVacina.setVisibility(VISIBLE);
                    btDeletarVacina.setVisibility(VISIBLE);
                    btAtualizarVacina.setVisibility(VISIBLE);
                }

            }
        });

        dt_vacinacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (btDeletarVacina.getVisibility() == VISIBLE) {
                    verificarBt = false;
                } else if (btSalvarVacina.getVisibility() == VISIBLE) {
                    verificarBt = true;
                }

                funMostrarCalendar();
            }
        });

        filtrarEspecieVac.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (primeiraSelecaoSpinner) {
                    primeiraSelecaoSpinner = false; // ignora a primeira seleção
                    return;
                }

                String especieSelecionada = filtrarEspecieVac.getSelectedItem().toString();

                // Verifica se a espécie selecionada é diferente da última seleção
                if (!especieSelecionada.equals(ultimaEspecieSelecionada)) {
                    ultimaEspecieSelecionada = especieSelecionada;

                    try {
                        Connection con = ConexaoMysql.conectar();
                        String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ? AND especie = ?";
                        PreparedStatement stmt = con.prepareStatement(sql);
                        stmt.setInt(1, idUsuarioAtual);
                        stmt.setString(2, especieSelecionada);
                        ResultSet rs = stmt.executeQuery();

                        // Limpar as listas antes de adicionar novos dados
                        listaIdPetVac.clear();
                        listaNomePetVac.clear();
                        listaFotoPetVac.clear();

                        // Preencher as listas com dados do banco
                        while (rs.next()) {
                            String id1 = rs.getString("id_pet");
                            String nome = rs.getString("nome");
                            byte[] fotoBytes = rs.getBytes("foto");

                            // Converter a foto para Bitmap
                            Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                            // Chama o método para arredondar a imagem
                            Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                            // Adicionar os dados nas listas
                            listaIdPetVac.add(id1);
                            listaNomePetVac.add(nome);
                            listaFotoPetVac.add(roundedBitmap);
                        }

                        rs.close();
                        stmt.close();
                        con.close();

                        // Atualize o RecyclerView com os dados filtrados
                        updateRecyclerView();

                        funStartLayout();

                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btSalvarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nome_vacina.getText().toString().trim();
                String data = dt_vacinacao.getText().toString().trim();

                if (nome.isEmpty()) {
                    nome_vacina.setError("campo obrigatório");
                    return;
                }

                if (data.isEmpty()) {
                    dt_vacinacao.setError("campo obrigatório");
                    return;
                }

                funAdicionarCartao();

            }
        });

        btAddNovaVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funMostrarListaVacina();
                funLimparCamposVacina();
                funAtivarCamposVacina();
            }
        });

        btAlterarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCamposVacina();
                btAlterarVacina.setVisibility(GONE);
                btSalvarVacina.setVisibility(GONE);
                btAtualizarVacina.setVisibility(VISIBLE);
            }
        });

        btDeletarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Confirme para excluir a vacina " +nomeVacinaClicada+".")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarCartao();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        btAtualizarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nome_vacina.getText().toString().trim();
                String data = dt_vacinacao.getText().toString().trim();

                if (nome.isEmpty()) {
                    nome_vacina.setError("campo obrigatório");
                    return;
                }

                if (data.isEmpty()) {
                    dt_vacinacao.setError("campo obrigatório");
                    return;
                }

                funAtualizarCartao();

            }
        });

        btVacAplicadas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btVacAplicadas.setVisibility(GONE);
                btVacProximas.setVisibility(VISIBLE);
                funListaCartaoAplicadas();
            }
        });

        btVacProximas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btVacProximas.setVisibility(GONE);
                btVacAplicadas.setVisibility(VISIBLE);
                funListaCartaoProximas();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funListaPets(); // Primeiro carrega os pets
        funFiltrarEspecie();

        if (petIsNull) {
            funPetNull(); // Chama se não houver pets
        } else {
            funStartLayout();
        }

    }

    public void funListaPets() {
        petIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdPetVac.clear();
            listaNomePetVac.clear();
            listaFotoPetVac.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_pet");
                String nome = rs.getString("nome");
                byte[] fotoBytes = rs.getBytes("foto");

                // Converter a foto para Bitmap
                Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                // Chama o método para arredondar a imagem
                Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                // Adicionar os dados nas listas
                listaIdPetVac.add(id);
                listaNomePetVac.add(nome);
                listaFotoPetVac.add(roundedBitmap);

                petIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            // Atualize o RecyclerView com os dados
            updateRecyclerView();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModels.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdPetVac.size(); i++) {
            MainModelVacina model = new MainModelVacina(listaFotoPetVac.get(i), listaNomePetVac.get(i), listaIdPetVac.get(i));
            mainModels.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapter.notifyDataSetChanged();
    }

    public void updateRecyclerViewCartao() {
        mainModelsCartao.clear();
        for (int i = 0; i < listaIdCartao.size(); i++) {
            MainModelCartaoVacina model = new MainModelCartaoVacina(listaIdCartao.get(i), listaNomeCartao.get(i), listadtVacina.get(i));
            mainModelsCartao.add(model);
        }

        if (mainAdapterCartao == null) {
            mainAdapterCartao = new MainAdapterCartaoVacina(getContext(), mainModelsCartao, new MainAdapterCartaoVacina.OnItemClickListener() {
                @Override
                public void onItemClick(MainModelCartaoVacina model) {
                    // Aqui você trata o clique do item
                }
            });
            listaCartaoVacina.setAdapter(mainAdapterCartao);
        } else {
            mainAdapterCartao.notifyDataSetChanged();
        }
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }

    public void funFiltrarEspecie() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT DISTINCT especie FROM pet WHERE fk_id_tutor = ? ORDER BY especie ASC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Criar uma lista de String para o Spinner
            List<String> filtrarEspecieList = new ArrayList<>();

            while (rs.next()) {
                filtrarEspecieList.add(rs.getString("especie"));
            }

            // Criar o ArrayAdapter e associar ao Spinner
            ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getActivity(), R.layout.spinner_item, filtrarEspecieList);
            adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            filtrarEspecieVac.setAdapter(adapter2);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funAdicionarCartao() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "INSERT INTO cartao_vacinacao (nome_vacina, dt_vacinacao, lote_vacina, medico_vet, clinica_vet, fk_id_pet)" +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);

            // Converte a data de String para java.sql.Date com tratamento de erro
            java.sql.Date dataSql = null;
            try {
                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                Date dataUtil = formato.parse(dt_vacinacao.getText().toString().trim()); // String da data
                dataSql = new java.sql.Date(dataUtil.getTime());
            } catch (ParseException e) {
                e.printStackTrace();
                Toast.makeText(getActivity(), "Data de nascimento inválida", Toast.LENGTH_SHORT).show();
                return; // Encerra a execução se a data for inválida
            }

            stmt.setString(1, nome_vacina.getText().toString().trim());
            stmt.setDate(2, dataSql);
            stmt.setString(3, lote_vacina.getText().toString().trim());
            stmt.setString(4, medico_vet.getText().toString().trim());
            stmt.setString(5, clinica_vet.getText().toString().trim());
            stmt.setInt(6, idPetClicadoVac);
            stmt.executeUpdate();

            stmt.close();
            con.close();

            funListaCartao();
            funLimparCamposVacina();
            funEsconderListaVacina();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funAtualizarCartao() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "UPDATE cartao_vacinacao SET nome_vacina = ?, dt_vacinacao = ?, lote_vacina = ?, " +
                    "medico_vet = ?, clinica_vet = ? WHERE id_cartao_vacinacao = ?";
            PreparedStatement stmt = con.prepareStatement(sql);

            // Converte a data de String para java.sql.Date com tratamento de erro
            java.sql.Date dataSql = null;
            try {
                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                Date dataUtil = formato.parse(dt_vacinacao.getText().toString().trim()); // String da data
                dataSql = new java.sql.Date(dataUtil.getTime());
            } catch (ParseException e) {
                e.printStackTrace();
                Toast.makeText(getActivity(), "Data de nascimento inválida", Toast.LENGTH_SHORT).show();
                return; // Encerra a execução se a data for inválida
            }

            stmt.setString(1, nome_vacina.getText().toString().trim());
            stmt.setDate(2, dataSql);
            stmt.setString(3, lote_vacina.getText().toString().trim());
            stmt.setString(4, medico_vet.getText().toString().trim());
            stmt.setString(5, clinica_vet.getText().toString().trim());
            stmt.setInt(6, idCartaoClicado);
            stmt.executeUpdate();

            stmt.close();
            con.close();

            funListaCartao();
            funLimparCamposVacina();
            funEsconderListaVacina();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funDeletarCartao() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM cartao_vacinacao WHERE id_cartao_vacinacao = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idCartaoClicado);
            stmt.executeUpdate();

            stmt.close();
            con.close();

            funListaCartao();
            funLimparCamposVacina();

            if (vacinaIsNull) {
                funStartLayout();
            } else {
                funEsconderListaVacina();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaCartao() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? ORDER BY id_cartao_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idPetClicadoVac);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdCartao.clear();
            listaNomeCartao.clear();
            listadtVacina.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_cartao_vacinacao");
                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                // Adicionar os dados nas listas
                listaIdCartao.add(id);
                listaNomeCartao.add(nome);
                listadtVacina.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerViewCartao();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaCartaoProximas() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? AND dt_vacinacao >= CURRENT_DATE " +
                    "ORDER BY dt_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idPetClicadoVac);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdCartao.clear();
            listaNomeCartao.clear();
            listadtVacina.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_cartao_vacinacao");
                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                // Adicionar os dados nas listas
                listaIdCartao.add(id);
                listaNomeCartao.add(nome);
                listadtVacina.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerViewCartao();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaCartaoAplicadas() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? AND dt_vacinacao < CURRENT_DATE " +
                    "ORDER BY dt_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idPetClicadoVac);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdCartao.clear();
            listaNomeCartao.clear();
            listadtVacina.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_cartao_vacinacao");
                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                // Adicionar os dados nas listas
                listaIdCartao.add(id);
                listaNomeCartao.add(nome);
                listadtVacina.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerViewCartao();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funAtivarCamposVacina() {
        nome_vacina.setFocusable(true);
        nome_vacina.setFocusableInTouchMode(true);
        nome_vacina.setCursorVisible(true);
        nome_vacina.setLongClickable(true);

        lote_vacina.setFocusable(true);
        lote_vacina.setFocusableInTouchMode(true);
        lote_vacina.setCursorVisible(true);
        lote_vacina.setLongClickable(true);

        medico_vet.setFocusable(true);
        medico_vet.setFocusableInTouchMode(true);
        medico_vet.setCursorVisible(true);
        medico_vet.setLongClickable(true);

        clinica_vet.setFocusable(true);
        clinica_vet.setFocusableInTouchMode(true);
        clinica_vet.setCursorVisible(true);
        clinica_vet.setLongClickable(true);

        dt_vacinacao.setEnabled(true);

    }

    public void funDesativarCamposVacina() {
        nome_vacina.setFocusable(false);
        nome_vacina.setFocusableInTouchMode(false);
        nome_vacina.setCursorVisible(false);
        nome_vacina.setLongClickable(false);

        lote_vacina.setFocusable(false);
        lote_vacina.setFocusableInTouchMode(false);
        lote_vacina.setCursorVisible(false);
        lote_vacina.setLongClickable(false);

        dt_vacinacao.setFocusable(false);
        dt_vacinacao.setFocusableInTouchMode(false);
        dt_vacinacao.setCursorVisible(false);
        dt_vacinacao.setLongClickable(false);

        dt_vacinacao.setEnabled(false);

        medico_vet.setFocusable(false);
        medico_vet.setFocusableInTouchMode(false);
        medico_vet.setCursorVisible(false);
        medico_vet.setLongClickable(false);

        clinica_vet.setFocusable(false);
        clinica_vet.setFocusableInTouchMode(false);
        clinica_vet.setCursorVisible(false);
        clinica_vet.setLongClickable(false);

        nome_vacina.setError(null);
        dt_vacinacao.setError(null);
    }

    public void funEsconderListaVacina() {
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        calendarVac.setVisibility(GONE);
        btVacAplicadas.setVisibility(GONE);
        btVacProximas.setVisibility(VISIBLE);
        tvVacinas.setVisibility(VISIBLE);
        btAddNovaVacina.setVisibility(VISIBLE);
        listaCartaoVacina.setVisibility(VISIBLE);
    }

    public void funMostrarListaVacina() {
        btVacAplicadas.setVisibility(GONE);
        btVacProximas.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        calendarVac.setVisibility(GONE);
        tvNovaVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        btSalvarVacina.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);

        tvFiltrarEspecieVac.setVisibility(VISIBLE);
        filtrarEspecieVac.setVisibility(VISIBLE);
        listaVacina.setVisibility(VISIBLE);
    }

    public void funLimparCamposVacina() {
        nome_vacina.setText(null);
        lote_vacina.setText(null);
        dt_vacinacao.setText(null);
        medico_vet.setText(null);
        clinica_vet.setText(null);
        nome_vacina.setError(null);
        dt_vacinacao.setError(null);
    }

    public void funPetNull() {
        btAddNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        calendarVac.setVisibility(GONE);
        btVacAplicadas.setVisibility(GONE);
        btVacProximas.setVisibility(GONE);

        // Oculta o RecyclerView de pets e cartões de vacina
        listaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);

        // Oculta spinner
        if (filtrarEspecieVac != null) {
            filtrarEspecieVac.setVisibility(GONE);
        }
        tvFiltrarEspecieVac.setVisibility(GONE);

        // Mostra uma mensagem informando que o usuário não tem pets cadastrados
        tvPetNull.setVisibility(VISIBLE);
        tvPetNull.setText("Você ainda não cadastrou nenhum PET.");
    }

    public void funVacinaNull() {
        btVacAplicadas.setVisibility(GONE);
        btVacProximas.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        tvPetNull.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        calendarVac.setVisibility(GONE);
        tvNovaVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        btSalvarVacina.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);
    }

    public void funStartLayout() {
        btVacAplicadas.setVisibility(GONE);
        btVacProximas.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        calendarVac.setVisibility(GONE);
    }

    public void funMostrarVacinas() {
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        calendarVac.setVisibility(GONE);
        btVacAplicadas.setVisibility(GONE);
        btVacProximas.setVisibility(VISIBLE);
        tvVacinas.setVisibility(VISIBLE);
        btAddNovaVacina.setVisibility(VISIBLE);
        listaCartaoVacina.setVisibility(VISIBLE);
    }

    public void funMostrarLayoutVacina() {
        btSalvarVacina.setVisibility(GONE);
        tvPetNull.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        calendarVac.setVisibility(GONE);
        btVacAplicadas.setVisibility(GONE);
        btVacProximas.setVisibility(GONE);
        tvVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);
        btAlterarVacina.setVisibility(VISIBLE);
        btDeletarVacina.setVisibility(VISIBLE);
    }

    public void funMostrarCalendar() {
        btAddNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        calendarVac.setVisibility(GONE);
        listaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvPetNull.setVisibility(GONE);
        btVacProximas.setVisibility(GONE);
        btVacAplicadas.setVisibility(GONE);

        // Oculta spinner
        if (filtrarEspecieVac != null) {
            filtrarEspecieVac.setVisibility(GONE);
        }
        tvFiltrarEspecieVac.setVisibility(GONE);

        calendarVac.setVisibility(VISIBLE);
    }

}